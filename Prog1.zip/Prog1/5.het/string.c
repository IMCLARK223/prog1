#include <stdio.h>
#include "prog1.h"

char get_int(string szoveg)
{
    int a;
    printf("%s", szoveg);
    scanf("%d", &a);
    return a;
}

int main()
{
    //string szoveg= "Hello";
    string nev = get_int("Neved :");
    printf("Hello %s!\n", nev);
    int szam = get_int("Adjon meg egy számot! ");
    printf("A megadott szám: %d\n", szam);


    return 0;

}
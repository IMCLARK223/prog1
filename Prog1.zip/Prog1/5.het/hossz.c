#include <stdio.h>
#include "prog1.h"
#include <string.h>


int my_strlen(string szoveg)
{
    int darab = 0;
    int i = 0;
    while(szoveg[i] != '\0')
    {
        i++;
        darab++;
    }
    return darab;
}

int main(){

    string szoveg = "hello";
    printf("A szoveg hossza: %d\n", my_strlen(szoveg));

    return 0;

}
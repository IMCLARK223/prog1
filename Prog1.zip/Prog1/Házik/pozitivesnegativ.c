#include <stdio.h>

int main(){

    int szam;
    int szamlalo_pozitiv = 0;
    int szamlalo_negativ = 0;
    printf("Adjon meg egy szamot (vege 0) : ");
    scanf("%d", &szam);
    if(szam > 0){
            szamlalo_pozitiv++;
        }
        else if(szam < 0){
            szamlalo_negativ++;
        }
    while (szam != 0)
    {
        printf("Adjon meg egy szamot (vege 0) : ");
        scanf("%d", &szam);
        if(szam > 0){
            szamlalo_pozitiv++;
        }
        else if(szam < 0){
            szamlalo_negativ++;
        }

    }
    printf("A pozitiv szamok darabszama : %d\n", szamlalo_pozitiv);
    printf("A negatív szamok darabszama : %d\n", szamlalo_negativ);
    

return 0;

}
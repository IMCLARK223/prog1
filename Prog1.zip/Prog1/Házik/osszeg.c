#include <stdio.h>

int main(){

    int szam;
    int osszeg = 0;
    printf("Adjon meg egy szamot (vege 0) : \n");
    scanf("%d", &szam);
    while (szam != 0)
    {
        printf("Adjon meg egy szamot (vege 0) : \n");
        scanf("%d", &szam);
        osszeg += szam;
    }

    printf("A szamok osszege : %d\n", osszeg);
    

return 0;

}
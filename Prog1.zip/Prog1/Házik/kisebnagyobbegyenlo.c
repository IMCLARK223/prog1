#include <stdio.h>

int main(){

    int a;
    int b;

    printf("Adja meg az elso szamot : ");
    scanf("%d", &a);
    printf("\nAdja meg a masodik szamot :");
    scanf("%d", &b);

    printf("\n");

    if(a > b){
        printf("%d > %d\n", a, b);
    }
    else if(a < b){
        printf("%d < %d\n", a, b);
    }
    else{
        printf("%d = %d\n", a, b);
    }


return 0;

}
#include <stdio.h>

typedef struct 
{
    int x;
    int y;
} Pont;

double distance(Pont *p1, Pont *p2)
{
    
}

int main(){

    Pont a = {1, 2};
    Pont b = {6, 5};

    printf("A két pont közötti távolság: %f\n", distance(&a, &b));

    return 0;

}
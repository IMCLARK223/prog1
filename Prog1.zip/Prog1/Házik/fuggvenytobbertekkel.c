#include <stdio.h>
#include <stdlib.h>
#define SIZE 10

void get_number(int tomb[], int *Alegkisebb, int *Alegnagyobb, int *Aatlag)
{
    int kicsi = 100;
    int nagy = 0;
    int osszeg = 0;
    for(int i = 0; i < SIZE; i++)
    {
        osszeg += tomb[i];
        if(tomb[i] > nagy)
        {
            nagy = tomb[i];
            *Alegnagyobb = nagy;
        }
        if(tomb[i] < kicsi)
        {
            kicsi = tomb[i];
            *Alegkisebb = kicsi;
        }
    }
    *Aatlag = osszeg/SIZE;
}

    
int main()
{
    
    int tomb[SIZE] = {};
    int tombhossz = SIZE;
    for(int j = 0; j < SIZE ; j++)
    {
        tomb[j] = 0;
    }
    int legkisebb;
    int legnagyobb;
    int atlag;
    printf("A tömb elemei: ");
    for(int i = 0; i < SIZE ; i++)
    {
        tomb[i] = rand() % 89 + 10;
        printf("%d ", tomb[i]);
        get_number(tomb, &legkisebb, &legnagyobb, &atlag);
    }
    puts("");
    printf("A legkisebb elem : %d",legkisebb);
    puts("");
    printf("A legnagyobb elem: %d", legnagyobb);
    puts("");
    printf("A tömb átlaga : %d", atlag);
    puts("");

    return 0;

}
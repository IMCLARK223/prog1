#include <stdio.h>
#include "prog1.h"
#include <string.h>
#include <stdlib.h>
#define SIZE 50

int find_char(string s, char c){
    int hossz = strlen(s);

    for(int i = 0; i < hossz; i++)
    {
        if(s[i] == c)
        {
            return 0;
        }
    } 
    return 1;
}

int my_strlen(string s)
{
    int darab = 0;
    int i = 0;
    while(s[i] != '\0')
    {
        i++;
        darab++;
    }
    return darab;
}

int contains_char(string s , char c)
{
    return find_char(s,c) >= 0;
}

int main(){

    string s;
    char c = '*';
    int szoszamlalo = 0;
    int hossz = 0;
    int leghosszabb = 0;

    for(int i = 0; i < SIZE ; i++)
    {
        printf("Szó: ");
        fgets(s,SIZE,stdin);
        if(contains_char(s,c))
        {
            szoszamlalo++;
            hossz = my_strlen(s);
            if (hossz > leghosszabb)
            {
                leghosszabb = hossz;
            }

            
        }
    }
    puts("");
    printf("%d db szó van megadva. ", szoszamlalo);
    printf("Legtöbb karakter egy szóba %d ", leghosszabb);


    return 0;

}
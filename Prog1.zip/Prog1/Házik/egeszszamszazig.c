#include <stdio.h>

int main(){

    int i;
    int osszeg = 0;
    for(i = 0;i <= 100; i++){
        if(i > 0){
            osszeg += i;
        }
    }
    printf("Szamok osszege 1-100 ig: %d\n", osszeg);

return 0;

}
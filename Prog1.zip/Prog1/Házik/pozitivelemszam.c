#include <stdio.h>

int main(){

    int szam;
    int szamlalo = 0;
    printf("Adjon meg egy szamot (vege 0) :\n");
    scanf("%d", &szam);
    if(szam > 0){
            szamlalo++;
        }
    while (szam != 0)
    {
        printf("Adjon meg egy szamot (vege 0) :\n");
        scanf("%d", &szam);
        if(szam > 0){
            szamlalo++;
        }

    }
    printf("A pozitiv szamok darabszama : %d\n", szamlalo);
    

return 0;

}
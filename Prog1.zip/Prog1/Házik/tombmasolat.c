#include <stdio.h>

int main(){

    int size;
    printf("Hány db számot szeretnél megadni?\n");
    scanf("%d", &size);
    int tomb[size];
    int jtomb[size];
    int szam;
    for(int i = 0 ; i < size ; i++)
    {
        printf("%d.szám: ", i+1);
        scanf("%d", &szam);
        if(szam < 0)
        {
            jtomb[i] = szam*-1;
            tomb[i] = szam;
        }
        else
        {
            jtomb[i] = szam;
            tomb[i] = szam;
        }
    }
    
    printf("\nA megadott számok : ");

    for(int j = 0 ; j < size ; j++)
    {
        printf("%d  ", tomb[j]);
    }

    printf("\nA megadott számok abszolultértéke : ");

    for(int k = 0 ; k < size ; k++)
    {
        printf("%d  ", jtomb[k]);
    }
    puts("");

    return 0;

}
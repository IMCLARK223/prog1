#include <stdio.h>

int main(){

    int szam;
    scanf("%d", &szam);
    printf("%d", szam/2);

return 0;

}
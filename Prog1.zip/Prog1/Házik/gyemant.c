#include <stdio.h>

int main()
{
    int x, i, sor;
    printf("Adja meg a magasságot: ");
    scanf("%d", &x);
    if(x % 2 == 0){
        printf("Csak páratlan számra műkodik a program!\n");
        return 0;
    }
    else{
        int m = x/2 +1;
        printf("\n");

        for(sor = 1; sor <= m; sor++)
        {
            for(i = 1; i <= m - sor; i++)
            {
                printf(" ");
            }
            for(i = 1; i <= 2 * sor - 1 ;i++)
            {
                printf("#");
            }
            printf("\n");
        }
        for(sor = 1; sor <= m - 1; sor++)
        {
            for(i = 1; i <= sor; i++)
            {
                printf(" ");
            }
            for(i = 1; i<= 2 * (m-sor) - 1; i++)
            {
                printf("#");
            }
            printf("\n");
        }
        
    }
    return 0;

}
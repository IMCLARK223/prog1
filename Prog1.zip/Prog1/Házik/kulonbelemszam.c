#include <stdio.h>

int main(){

   int szam;
   int szamlaloszamtomb[100];
   int szamtomb[100];
   int darabszam = 0;
   int szamlalo = 0;
   for (int i = 0; i < 100; i++)
   {
       szamlaloszamtomb[i] = 0;
       szamtomb[i] = 0;
   }
   printf("Szám: ");
   scanf("%d", &szam);
   while (szam != 0 && szam < 99)
   {
       szamtomb[szamlalo] += szam;
       szamlalo++;
       szamlaloszamtomb[szam]++;
       printf("Szám: ");
       scanf("%d", &szam);  
   }    
   for (int k = 0 ; k < 100 ; k++)
   {
       if(szamlaloszamtomb[k] != 0)
       {
           darabszam++;
       }
   }
   printf("Ennyi különböző szám lett megadva: %d!\n", darabszam);
   printf("Ezek sorrendbe : ");
   for(int g = 0 ; g < szamlalo ; g++)
   {
       if(szamtomb[g] != szamtomb[g+1])
       {
           printf("%d ", szamtomb[g]);
       }
   }
   puts("");
   
    return 0;

}
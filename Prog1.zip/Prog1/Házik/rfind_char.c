#include <stdio.h>
#include "prog1.h"
#include <string.h>

int rfind_char(string szoveg, char c)
{
	int ertek = 1;
	for(int i = 0; i< strlen(szoveg);i++)
	{
		if(szoveg[i]== c)
		{
			ertek = i;
		}
		
	}
	return ertek;
}

int main()
{
	string szo= "A pelda szavunk";
	char c = 'a';
	printf("A utolsó előfordulási helye a megadott betünek a szóban a %d. helyen van\n",rfind_char(szo,c));
	return 0;
}
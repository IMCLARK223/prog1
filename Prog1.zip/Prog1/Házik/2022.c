#include <stdio.h>

int main(){

    char felkialtojel = '!' , kettospont = ':' , l = 'l'; 
    puts("");
    printf("%d\n", felkialtojel*kettospont+l);

    return 0;

}
#include <stdio.h>
#include "prog1.h"
#include <string.h>
#include <stdlib.h>

#define SIZE 50

int my_strlen(string szo)
{
    int darab = 0;
    int i = 0;
    while(szo[i] != '\0')
    {
        i++;
        darab++;
    }
    return darab;
}
int main()
{

    string szo;
    int szoszamlalo = 0;
    int leghosszabbszo = 0;
    int hossz = 0;
    for(int i = 0; i < 100 ; i++)
    {
        printf("Szó: ");
        fgets(szo,SIZE,stdin);
        if(strcmp("*", szo) == 0)
        {
            break;
        }
        else
        {
            hossz = my_strlen(szo);
            if(hossz > leghosszabbszo)
            {
                leghosszabbszo = hossz;
            }
            szoszamlalo++;
        }
    }

    puts("");
    printf("%d db szót adtál meg.", szoszamlalo);
    printf("A legtöbb karakterből álló szó %d !", leghosszabbszo);
    

    return 0;

}
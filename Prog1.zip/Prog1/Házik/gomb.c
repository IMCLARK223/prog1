#include <stdio.h>

double get_double()
{
    double szam;
    while (1)
    {
         printf("Adja meg a gomb sugarat! : \n");
         scanf("%lf", &szam);
         if(szam > 0){
             break;
         }

    }
    return szam;
    
}

double felszin(double a)
{
    double A = (4*(a*a)*3.14);
    return A;
}

double terfogat(double b)
{
    double V = ((4*(b*b*b)*3.14)/3);
    return V;
}

int main(){

    double sugar = get_double();
    printf("A gomb felszine: %lf\n", felszin(sugar));
    printf("A gomb terfogata: %lf\n", terfogat(sugar));
    

return 0;

}
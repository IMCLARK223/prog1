#include <stdio.h>
#include "prog1.h"
#include <string.h>

int my_strlen(string szoveg)
{
    int darab = 0;
    int i = 0;
    while(szoveg[i] != '\0')
    {
        i++;
        darab++;
    }
    return darab;
}


int main(){

   string s;
   int hossz = 0;
   int leghosszabb = 0;
   char szavak[100];
   int darab = 0;
   int szamlalo = 0;
   int csillagmutato = 0;

	s = fgets(szavak,100,stdin);
    fgets(szavak,100,stdin);
	szamlalo++;
   while(s[csillagmutato] != '*')
   {
		s = gfgets(szavak,100,stdin);
		
		szamlalo++;
        hossz = my_strlen(s);
        if(hossz > leghosszabb)
        {
             leghosszabb = hossz;
        }
   }
   printf("%d db szot adtal meg! ",szamlalo-1);
   printf("A legtöbbkarakter egy szóba %d !", leghosszabb);


   return 0;

}
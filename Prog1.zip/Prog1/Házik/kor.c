#include <stdio.h>

float kerulet(float a)
{
    float K = (2*a)*3.14;
    return K;
}
float terulet(float b)
{
    float T = (b*b)*3.14;
    return T;
}

int main(){

    float sugar;
    
    printf("Adja meg a kor sugarat! :");
    scanf("%f", &sugar);
    printf("\n");
    printf("A kor kerulete: %.2f\n", kerulet(sugar));
    printf("A kor terulete: %.2f\n", terulet(sugar));

return 0;

}
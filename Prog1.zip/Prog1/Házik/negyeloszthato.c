#include <stdio.h>

int main(){

    int i;
    printf("Adjon meg egy szamot mint intervallmot (0--X) : ");
    scanf("%d", &i);
    for (int j = 1; j <= i; j++)
    {
        if(j % 4 == 0)
        printf("%d\n", j);
    }
    

return 0;

}
#include <stdio.h>
#include <string.h>
#include "prog1.h"

#define SIZE 27

string feltolt(char tomb[])
{
    for(int i = 0; i < SIZE; i++)
    {
        tomb[i] = 'a' +i;
    }
    string szo = tomb;
    return szo;
}

int main(){

    char tomb[SIZE];
    feltolt(tomb);
    for(int i = 0; i < SIZE; i++)
    {
        printf("%s ", szo);
    }
    puts("");

    return 0;

}
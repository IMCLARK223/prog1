#include <stdio.h>
#include <stdlib.h>

int main(int argc, int argv[]){

    if(argc == 1)
    {
        printf("Hiba! Az argumentumok nem megfelelőek! Adjon meg 2 argumentumot!\n");
        exit(1);
        puts(" ");
    }
    else if(argc > 3)
    {
        printf("Hiba! Az argumentumok nem megfelelőek! Adjon meg 2 argumentumot!\n");
        exit(1);
        puts(" ");
    }
    else
    {
        printf("A ket szam osszege %d \n", argv[2]-argv[3]);
    }


    return 0;

}
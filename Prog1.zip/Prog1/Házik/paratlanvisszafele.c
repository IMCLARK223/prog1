#include <stdio.h>

int main(){

    int i;
    printf("Adjon meg egy intervallumot (X--1): " );
    scanf("%d", &i);
    for(i ; i > 1; i--){
        if(i % 2 == 1){
            printf("\n%d\n", i);
        }
    }

return 0;

}
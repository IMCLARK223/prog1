#include <stdio.h>

void tomb_kiir(int meret, int tomb[]){
    int j;
    for(int i=0; i < meret-1;i++)
    {
        printf("%d ,", tomb[i]);
        j = i;
    }
    printf("%d\n",tomb[j+1]);
}

int main(){

    int szamok[10]={12,43,23,54,6,7,8,32,6,49};
    int meret = 10;
    tomb_kiir(meret, szamok);
  
    

    return 0;

}
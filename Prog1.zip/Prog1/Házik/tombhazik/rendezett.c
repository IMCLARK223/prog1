#include <stdio.h>

int is_rendezett(int meret, int tomb[])
{
    for (int i = 0; i < meret; i++)
    {
        if(tomb[i+1] < tomb[i])
        {
            return 0;
        }
    }

    return 1; 
}

int main(){

    int tomb1[5] = {1,2,3,4,5};
    int meret1 = 5;
    int tomb2[5] = {1,3,4,5,2};
    int meret2 = 5;
    if(is_rendezett(meret1,tomb1))
    {
        printf("A 1-es tömb rendezett!\n");
    }
    else
    {
        printf("Az 1-es tömb nem rendezett!\n");
    }
    if(is_rendezett(meret2,tomb2))
    {
        printf("A 2-es tömb rendezett!\n");
    }
    else
    {
        printf("A 2-es tömb nem rendezett!\n");
    }

    return 0;

}
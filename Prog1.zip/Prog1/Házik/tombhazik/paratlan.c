#include <stdio.h>

int is_odd(int szam)
{
    if(szam % 2 == 0){
        return 1;
    }
    else{
        return 0;
    }
}

int main()
{
    int szam;
    printf("Adj megy egy egészet : ");
    scanf("%d", &szam);
    if(is_odd(szam)){
        printf("A szám páros\n");
    }
    else{
        printf("A szám páratlan\n");
    }

    return 0;

}
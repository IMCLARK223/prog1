#include <stdio.h>

int valid_triangle(double a, double b, double c)
{
    if(a < 0 || b < 0 || c < 0)
    {
        return 0;
    }
    else if ((a + b  < c) || (c + b < a) || (a + c < b))
    {
        return 0;
    }
    else
    {
        return 1;
    }

}


int main()
{
    double a, b, c;
    printf("Add meg a háromszög három oldalát: \n");
    printf("Első oldalhossz : ");
    scanf("%lf", &a);
    printf("Második oldalhossz : ");
    scanf("%lf", &b);
    printf("Harmadik oldalhossz : ");
    scanf("%lf", &c);
    if(valid_triangle(a,b,c))
    {
        printf("A háromszög megrajzolható!\n" );
    }
    else
    {
        printf("A háromszög nem rajzolható meg!\n");
    }
    

    return 0;

}
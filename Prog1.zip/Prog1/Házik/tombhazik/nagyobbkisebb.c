#include <stdio.h>

void legkisebb_kiir(int meret, int tomb[])
{
    int kicsi = 10000;
    int j = 0;
    for (int i = 0; i < meret; i++)
    {
        if(tomb[i] < kicsi)
        {
            kicsi = tomb[i];
            j = i;
        }
    }
    printf("A tomb legkisebb eleme a %d és értéke pedig %d !\n",j+1, kicsi);
    
}

void legnagyobb_kiir(int meret, int tomb[])
{
    int nagy = 0;
    int j = 0;
    for (int i = 0; i < meret; i++)
    {
        if(tomb[i] > nagy)
        {
            nagy = tomb[i];
            j = i;
        }
    }
    printf("A tomb legnagyobb eleme a %d és értéke pedig %d !\n",j+1, nagy);
    
}


int main(){
    int tomb[5] = {12,56,43,26,86};
    int meret = 5;
    legkisebb_kiir(meret,tomb);
    legnagyobb_kiir(meret,tomb);

    return 0;

}
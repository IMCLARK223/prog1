#include <stdio.h>

void tomb_kiir(int meret, int tomb[]){
    for(int i=0; i < meret;i++)
    {
        printf("A tömb %d. eleme: %d \n",i+1, tomb[i]);
    }
    puts("");

}

int sum(int meret, int tomb[])
{
    int osszeg = 0;
    for(int i =0;i < meret;i++)
    {
        osszeg += tomb[i];
    }
    return osszeg;
}

float avg(int meret, int tomb[])
{
    return sum(meret,tomb) / (float) meret;   
}

void swap(int meret,int tomb[])
{
    int i=0;
    int j= meret-1;
    int tmp;
    while(i<j)
    {
        tmp=tomb[i];
        tomb[i]=tomb[j];
        tomb[j]=tmp;
        i++;
        j--;
    }

}

int main(){

    int szamok[10]={12,43,23,78,56,7,87,32,2,93};
    int meret = 10;
    tomb_kiir(meret, szamok);
    
    printf("A tömb összege: %d\n",sum(meret, szamok));
    printf("A tömb átlaga: %.2f\n", avg(meret,szamok));
    printf("\n");

    swap(meret,szamok);
    tomb_kiir(meret,szamok);

    return 0;

}
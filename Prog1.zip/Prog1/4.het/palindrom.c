#include <stdio.h>

void tomb_kiir(int meret, int tomb[]){
    for(int i=0; i < meret;i++)
    {
        printf("A tömb %d. eleme: %d \n",i+1, tomb[i]);
    }
    puts("");

}

int sum(int meret, int tomb[])
{
    int osszeg = 0;
    for(int i =0;i < meret;i++)
    {
        osszeg += tomb[i];
    }
    return osszeg;
}

float avg(int meret, int tomb[])
{
    return sum(meret,tomb) / (float) meret;   
}

void swap(int meret,int tomb[])
{
    int i=0;
    int j= meret-1;
    int tmp;
    while(i<j)
    {
        tmp=tomb[i];
        tomb[i]=tomb[j];
        tomb[j]=tmp;
        i++;
        j--;
    }

}

int is_palindrom(int meret, int tomb[])
{
    int i =0;
    int j = meret-1;
    while (i < j)
    {
        if(tomb[i] != tomb[j])
        {
            return 0;
        }
        else
        {
            i++;
            j--;
        }
    }
    return 1;

    
}

int main(){

    int szamok[5]={5,3,1,7,8};
    int szamok2[5]={5,4,3,4,5};
    int meret = 5;
    tomb_kiir(meret, szamok);
    
    printf("A tömb összege: %d\n",sum(meret, szamok));
    printf("A tömb átlaga: %.2f\n", avg(meret,szamok));
    printf("\n");

    printf("Az elso tomb palindrom? %s \n", is_palindrom(meret,szamok) ? "igen" : "nem");
    printf("A masodik tomb palindrom? %s \n", is_palindrom(meret,szamok2) ? "igen" : "nem");
    printf("\n");

    swap(meret,szamok);
    tomb_kiir(meret,szamok);

    return 0;

}
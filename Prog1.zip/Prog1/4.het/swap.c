#include <stdio.h>

int main(){
    
    int a=5;
    int b=7;
    printf("A = %d \n",a);
    printf("B = %d \n",b);

    int c = 0;
    c=a;
    a=b;
    b=c;

    printf("A = %d \n",a);
    printf("B = %d \n",b);

    return 0;

}   
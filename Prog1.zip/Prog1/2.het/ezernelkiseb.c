#include <stdio.h>

int main()
{
    int i;
    int osszeg = 0;
    for(i =0;i <= 1000;i++)
    {
        if(i % 2 == 0)
        {
            osszeg += i;
        }
    }
    printf("%d\n", osszeg);
    return 0;
}
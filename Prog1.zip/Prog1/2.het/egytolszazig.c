#include <stdio.h>

int main()
{
    int i =0;
    int osszeg = 0;
    for (i;i <= 100; i++)
    {
        osszeg+=i;
    }
    printf("Egytol szazig a szamok osszege : %d\n", osszeg);

    return 0;
    
}
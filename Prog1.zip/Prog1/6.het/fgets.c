#include <stdio.h>
#include <string.h>

#define SIZE 50

int main()
{
    char tomb[SIZE];
    printf("Adj meg egy stringet!:\n");
    fgets(tomb, SIZE , stdin);
    printf("%s", tomb);

    return 0;

}
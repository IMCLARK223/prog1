#include <stdio.h>

int terulet(int oldal){
    return oldal*oldal;
}

int kerulet(int oldal){
    return 4*oldal;
}

int main(){

    int oldalhossz;
    printf("Adjon meg egy oldalhosszt : ");
    scanf("%d", &oldalhossz);
    printf("\n");
    printf("A negyzet kerulete : %d\n", kerulet(oldalhossz));
    printf("A negyzet terulete : %d\n", terulet(oldalhossz));

return 0;

}
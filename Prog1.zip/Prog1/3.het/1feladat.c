#include <stdio.h>

int main()
{
    int szam;
    int pozitiv = 0;
    int negativ = 0;
    do{
        printf("Adjon meg egy egesz szamot (vege :0)! : ");
        scanf("%d", &szam);
        if(szam < 0)
        {
            negativ++;
        }
        else if(szam > 0)
        {
            pozitiv++;
        }
    }while(szam != 0);

    printf("\n");
    printf("A beolvasott pozitiv elemek szama : %d\n", pozitiv);
    printf("A beolvasott negativ elemek szama : %d\n", negativ);

return 0;

}

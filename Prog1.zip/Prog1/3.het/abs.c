#include <stdio.h>

int abs(int n){
    if(n >= 0){
        return n;
    }
    else{
        return -1*n;
    }
}

int main(){

    int szam;
    printf("\n");

    printf("A szam erteke: %d\n", szam);
    printf("A szam abszolulterteke : %d\n",abs(szam));

    printf("\n");

return 0;

}
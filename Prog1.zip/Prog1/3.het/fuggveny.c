#include <stdio.h>


int duplazo(int n){
    return 2*n;
}

int main(){

    int a = 2;
    printf("\n");

    printf("Az a valtozo erteke : %d\n", a);
    printf("Az a valtozo duplaja : %d\n", duplazo(a));
    
    printf("\n");

return 0;

}
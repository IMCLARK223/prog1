#include <stdio.h>


void get_first_two_primes(int *p1, int *p2)
{
    *p1 = 2;
    *p2 = 3;
}

int main(){


    int a;
    int b;
    get_first_two_primes(&a,&b);
    printf("%d %d\n", a,b);

    return 0;

}

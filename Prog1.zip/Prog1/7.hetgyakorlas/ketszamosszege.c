#include <stdio.h>
#include "prog1.h"
#include <stdlib.h>

int main(int argc, string argv[]){

    if(argc != 3)
    {
        puts("HIBA KÉT PARAMÉTERT ADJ MEG!\n");
    }
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    int osszeg = a+b;
    printf("%d\n", osszeg);

    return 0;

}
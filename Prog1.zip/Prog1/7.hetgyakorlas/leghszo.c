#include <stdio.h>
#include <string.h>
#define BUFSIZE 200

int main(){


    int max = 0;
    int counter;
    char tomb[BUFSIZE];
    printf("Adja meg a szavakat '*' végjelig!\n");
    while(1)
    {
        printf("Szó: ");
        fgets(tomb,BUFSIZE,stdin);
        tomb[strlen(tomb)-1] = '\0';
        if(max < strlen(tomb))
        {
            max = strlen(tomb);
        }
        if(strcmp("*", tomb) == 0)
        {
            break;
        }
        counter++;
    }

    printf("%d db szót adtál meg. A leghosszabb szó %d karakterből áll.\n", counter, max);

    return 0;

}
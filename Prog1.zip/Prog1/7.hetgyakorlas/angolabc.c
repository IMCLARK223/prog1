#include <stdio.h>

#define SIZE 26

void feltolt(char tomb[])
{
    for(int i =0 ; i < SIZE ; i++)
    {
        tomb[i] = 'a' + i;
    }
    tomb[26] = '\0';
}

int main(){

    char tomb[SIZE+1];
    feltolt(tomb);
    printf("%s", tomb);
    puts("");

    return 0;

}
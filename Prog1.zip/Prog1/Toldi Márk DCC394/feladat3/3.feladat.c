#include <stdio.h>
#include "prog1.h"
#include <string.h>

int main()
{

    string szamok;
    

    return 0;

}
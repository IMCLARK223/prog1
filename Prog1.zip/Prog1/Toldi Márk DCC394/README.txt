* Ezt a könyvtárat majd nevezzék át
  a saját nevükre, és írják be a Neptun-kódjukat is!

  Az egyes részeket aláhúzásjellel válasszák el!
  A könyvtár nevében NE használjanak ékezeteket!

* Mit lehet használni?

  - saját írott jegyzet (nyomtatott jegyzetet nem fogadok el)
  - az előadás fóliái
  - CS50 dokumentáció
  - prog1 library (lásd `prog1/` mappa)

  Minden egyéb eszköz használata meg nem engedett segédeszköznek minősül.

* Tilos egymással kommunikálni a ZH ideje alatt.
  A saját, egyéni teljesítményükre vagyok kíváncsi.

* Meg nem engedett segédeszköz használata esetén a dolgozatra
  0 pontot kapnak.

* Minden egyes feladat megoldása kész, komplett, minden mástól
  független megoldás legyen. Vagyis a projekt a feladat mappájába
  belépve egyszerűen fordítható és futtatható legyen.

  Példa:

  $ cd feladatN
  $ gcc feladatN.c    # lefordul
  $ ./a.out           # lefut

* Ha kész vannak, akkor majd ezt a könyvtárat kell
  becsomagolni ZIP-be és feltölteni a tárgy Moodle oldalára.

  Példa:

      $ zip -r zh.zip Pelda_Peter_ABCDEF/

* Miután feltöltötték a megoldást, utólagos javításra már nincs lehetőség!

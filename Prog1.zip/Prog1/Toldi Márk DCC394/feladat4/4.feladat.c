#include <stdio.h>

int main()
{

    int szam;
    int pozitivszamlalo = 0;
    int legnagyobbszam = 0;
    int osszeg = 0;
    float atlag = 0;

    printf("Adjon megy egy pozitív egész számot! (Vége: 0) :");
    scanf("%d", &szam);
    if(szam > 0)
        {
            pozitivszamlalo++;
            osszeg += szam;
        } 
    while (szam != 0)
    {
        printf("Adjon megy egy pozitív egész számot! (Vége: 0) :");
        scanf("%d", &szam);
        if(szam > 0)
        {
            pozitivszamlalo++;
            osszeg += szam;
        } 
        if(szam < 0)
        {
            printf("HIBA ! Adjon meg egy pozitív egész számot!\n");
        }
        if(szam > legnagyobbszam)
        {
           legnagyobbszam = szam;
        }
        
    }
    atlag = (osszeg/pozitivszamlalo);
    puts("");
    printf("Pozitív értékek száma: %d", pozitivszamlalo);
    puts("");
    printf("A legnagyobb szám: %d", legnagyobbszam);
    puts("");
    printf("A számok átlaga: %.2f\n", atlag);
    
    

    return 0;

}
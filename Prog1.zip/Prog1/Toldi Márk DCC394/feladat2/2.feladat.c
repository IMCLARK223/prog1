#include <stdio.h>

int main()
{

    int szam = 1;
    int oszto = 1;
    int osztoszamlalo = 0;
    int osztoosszeg = 0;
    int tokeletesszam[500] = { };
    for(int i = 1; i <= 500; i++)
    {
        szam = i;
        oszto = 1;
        osztoosszeg = 0;
        for(int j = 1; j < szam; j++)
        {
            oszto = j;
            if((szam % oszto) == 0)
            {
             osztoosszeg += oszto;
                if(osztoosszeg > szam)
                {
                    break;
                }
            }
            if(osztoosszeg = szam)
            {
             tokeletesszam[j] = szam;
            }
        }
        for (int k = 0; k < 500; k++)
        {
            if(tokeletesszam[k] != 0)
            {
                printf("%d\n", tokeletesszam[k]);
            }
            
        }
    }

    return 0;

}

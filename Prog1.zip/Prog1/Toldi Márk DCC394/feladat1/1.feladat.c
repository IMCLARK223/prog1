#include <stdio.h>
#include "prog1.h"
#include <string.h>
#define SIZE 50

void simplify(string source)
{
    char egyszerusitett[50];
    for(int i = 0; i < strlen(source); i++)
    {
        for(int j = i+1; j <= strlen(source); j++)
        {
            if(source[i] != source[j])
            {
                egyszerusitett[i] = source[i];
            }
            else
            {
                egyszerusitett[i] = source[i+1];
            }
        }
        
    }
    printf("%s\n", egyszerusitett);
}

int main(int argc, string argv[])
{
    string szoveg = argv[1];
    if(argc == 1 || argc > 2)
    {
        printf("Hiba! Ajd meg pontosan egy sztringet!\n");
    }
    else
    {
        if(strlen(argv[1]) < 4)
        {
            printf("Hiba! Adj meg egy legalább 4 karakterből álló sztringet!\n");
        }
        else
        {
            simplify(szoveg);
        }
    }

    return 0;

}
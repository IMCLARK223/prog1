#include <stdio.h>

double bmi_kalkulator(double magassag, double suly)
{
    return suly/(magassag*magassag);
}

void tajekoztat(double bmi_ertek)
{
    if(bmi_ertek < 18.5)
    {
        printf("A testsulyozasi tablazat szerint a sovany vagy!\n");
    }
    else if(bmi_ertek > 18.5 && bmi_ertek < 25)
    {
        printf("A testsulyozasi tablazat szerint normal a testsulyod!\n");
    }
    else if(bmi_ertek > 25 && bmi_ertek < 30)
    {
        printf("A testsulyozasi tablazat szerint tulsolyos vagy!\n");
    }
    else if (bmi_ertek > 30)
    {
        printf("A testsulyozasi tablazat szerint el vagy hízva!\n");
    }
}

int main(){

    double magassag;
    double suly;
    double BMI;
    printf("Add meg a testmagassagodat meterben!\n");
    scanf("%lf", &magassag);
    printf("Add meg a testsulyodat kilogrammba!\n");
    scanf("%lf", &suly);
    BMI = bmi_kalkulator(magassag, suly);
    tajekoztat(BMI);
    
    

    return 0;

}

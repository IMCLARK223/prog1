#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    int veletlenszam, tipp, szamlalo = 0;
    srand(time(NULL));
    veletlenszam = rand() % 1000 + 1;
    do
    {
        printf("%d. tipp: ", ++szamlalo);
        scanf("%d", &tipp);
        if (veletlenszam < tipp)
        {
            printf("A gondolt szam < %d\n", tipp);
        }
        else if(veletlenszam > tipp)
        {
            printf("A gondolt szam > %d\n", tipp);
        }
    }
    while (tipp != veletlenszam);
    printf("Gratulalok %d lepesben kitalaltad a gondolt %d szamot!\n", szamlalo, veletlenszam);
    return 0;
}
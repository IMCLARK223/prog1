#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int ora_generator(int ora)
{
    srand(time(NULL));
    ora = rand() % 23;
    return ora;
}

int perc_generator(int perc)
{  
    srand(time(NULL));
    perc = rand() % 58;
    return perc;
}

void kiir(int ora, int perc)
{
    if(ora == 0 && perc == 0)
    {
        printf("0%d:0%d (ejfel)\n", ora,perc);
    }
    if(ora >= 0 && perc > 0 && ora !=0 && perc != 0 && ora <= 11 && perc <= 59 && ora !=0 && perc != 0)
    {
        if(ora < 10)
        {
            printf("0%d:%d (delelott)\n", ora,perc);
        }
        else if(perc < 10)
        {
            printf("%d:0%d (delelott)\n", ora,perc);
        }
        else if(ora < 10 && perc < 10)
        {
            printf("0%d:0%d (delelott)\n", ora,perc);
        }
        else
        {
            printf("%d:%d (delelott)\n", ora,perc);
        }  
    }
    if(ora == 12 && perc == 0)
    {
        printf("%d:%d (del)\n", ora,perc);
    }
    if(ora >= 12 && perc >= 1 && ora !=0 && perc != 0 && ora <= 23 && perc <= 59 && ora !=0 && perc != 0)
    {
        if(perc < 10)
        {
            printf("%d:0%d (delutan)\n", ora,perc);
        }
        else
        {
            printf("%d:%d (delutan)\n", ora,perc);
        }
    }
}

int main()
{
    int ora = 0;
    int perc = 0;
    kiir(ora_generator(ora), perc_generator(perc));
    return 0;

}
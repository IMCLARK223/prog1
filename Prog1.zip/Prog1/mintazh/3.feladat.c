#include <stdio.h>
#include "prog1.h"
#include <string.h>
#include <ctype.h>
#include <stdlib.h>


int main(int argc, string argv[])
{
    string nev = argv[1];
	char szamok[10] = {'0','1','2','3','4','5','6','7','8','9'};
    if(argc == 1 || argc > 2)
    {
        printf("Hiba! Pontosan egy nevet adj meg!\n");
        exit(0);
    }
    for(int i = 0;i<strlen(nev);i++)
    {
        {
			{
				for(int k = 0;k<=9;k++)
				{
					if(nev[i] == szamok[k])
					{
						printf("A nev helytelen karaktert tartalmaz!\n");
						return 0;
					}
					
				}
			}
    }   }
    if(argc == 2)
    {
        if(strlen(argv[1]) >= 3)
        {
            printf("A(z) %s megfelel meg a formai követelményeknek!\n", argv[1]);
        }
        else if(strlen(argv[1]) < 3)
        {
            printf("Hiba! A megadott nev tul rovid!\n");
            exit(0);
        }
        
    }


    return 0;

}
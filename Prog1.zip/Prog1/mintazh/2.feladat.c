#include <stdio.h>

int is_prime(int szam)
{
    int szorzoszamlalo = 0;
    for(int i = 1 ; i < szam ; i++)
    {
        if((szam % i) == 0)
        {
            szorzoszamlalo++;
        }
        if(szorzoszamlalo > 2 && i != szam)
        {
            return 0;
        }
        if(szorzoszamlalo == 2 && i == szam)
        {
            return 1;
        }
    }

}

int main(){

    int szam;
    printf("Adj megy egy primszamot:");
    scanf("%d", &szam);
    while(is_prime(szam) == 0)
    {
        printf("Ez nem prímszám! Próbáld újra!\n");
        printf("Adj megy egy primszamot:");
        scanf("%d", &szam);
    }
    for(int i = 1 ; i <= 10 ; i++)
    {
        printf("%d x %d = %d\n", szam, i, (szam*i));
    }

    return 0;

}